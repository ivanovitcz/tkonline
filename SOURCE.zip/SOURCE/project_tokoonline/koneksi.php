<?php 

$koneksi = mysqli_connect("localhost", "root", "" ,"project_tokoonline");

?>